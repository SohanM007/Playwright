import { expect, test } from "@playwright/test";
import { CartPage } from "../pages/cartPage";
import { DashboardPage } from "../pages/dashboardPage";
import { LoginPage } from "../pages/loginPage";
import { PaymentPage } from "../pages/paymentPage";
import loginData from "../testdata/login.json";
import paymentData from "../testdata/payment.json";

test("add a product to cart and place an order", async ({ page }) => {
  const loginPage = new LoginPage(page);
  const dashboardPage = new DashboardPage(page);
  const cartPage = new CartPage(page);
  const paymentPage = new PaymentPage(page);

  await loginPage.launchUrl(loginData.url);
  await loginPage.loginIntoApplication(loginData.email, loginData.password);
  await expect(loginPage.homePageIdentifier).toBeVisible();

  await dashboardPage.searchAndAddProduct(paymentData.productName, 1);
  await expect(dashboardPage.addToCartMessage).toBeVisible();
  await dashboardPage.navigateToCart();
  await expect(cartPage.productNames).toContainText(paymentData.productName);

  await cartPage.proceedToCheckout();
  await expect(paymentPage.nameOnCard).toBeVisible();
  await paymentPage.completePayment(paymentData);

  await expect(paymentPage.orderConfirmation).toHaveText(
    paymentData.orderConfirmationMessage,
  );
});